"""Setup file for cx_freeze """
#pylint: disable=c0103
import sys
import os.path
from cx_Freeze import setup, Executable

# <added>
PYTHON_INSTALL_DIR = os.path.dirname(os.path.dirname(os.__file__))
os.environ['TCL_LIBRARY'] = os.path.join(PYTHON_INSTALL_DIR, 'tcl', 'tcl8.6')
os.environ['TK_LIBRARY'] = os.path.join(PYTHON_INSTALL_DIR, 'tcl', 'tk8.6')
# </added>

base = None
if sys.platform == 'win32':
    base = 'Win32GUI'

executables = [
    Executable('gui.py', base=base)
]

# <added>
options = {
    'build_exe': {
        'include_files': [
            os.path.join(PYTHON_INSTALL_DIR, 'DLLs', 'tk86t.dll'),
            os.path.join(PYTHON_INSTALL_DIR, 'DLLs', 'tcl86t.dll'),
        ],
    },
}
# </added>

setup(
    name='gui',
    version='0.1',
    description='Sample cx_Freeze Tkinter script',
    # <added>
    options=options,
    # </added>
    executables=executables
)
